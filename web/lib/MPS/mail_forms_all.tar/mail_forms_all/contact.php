<script type="text/javascript" src="/js/mps/jquery-1.5.2.min.js"></script>
<script type="text/javascript" src="/js/mps/jquery.highlightFade.js"></script>
<script type="text/javascript" src="/js/mps/MailForms_validate.js"></script>
<script type="text/javascript" src="/js/mps/MailForms_addFormField.js"></script>
<script type="text/javascript" src="/js/mps/jquery.validate.min.js"></script>
<script type="text/javascript" src="/js/mps/additional-methods.min.js"></script>

<link rel="stylesheet" type="text/css" href="/js/mps/MailForms.css" media="all" />

<!--[if lt IE 9]>
	<link href="/js/mps/MailForms_ie8.css" rel="stylesheet" type="text/css" />
<![endif]-->
<script>
	jQuery.noConflict();
</script>
<div style="float:right;margin-bottom:20px;"><a href="?form=General">General</a> | <a href="?form=">Feedback</a> | <a href="?form=Catalog">Catalog</a> | <a href="?form=PowerchannelCatalog">Powerchannel Catalog</a> | <a href="?form=Newsletter">Newsletter</a> | <a href="?form=RFQ">RFQ</a> | <a href="?form=RMA">RMA</a> | <a href="?form=Sample">Sample</a> | <a href="?form=Special">Special</a> | <a href="?form=TechnicalSupport">Technical Support</a></div><br clear="all" />

<form id="MailForm" method="post" action="thankyou">
<?php
error_reporting (E_ALL ^ E_NOTICE);
if(isset($_GET['form'])){
$form = $_GET['form'];
}
switch($form){
	case "Catalog":
		include('subjCatalog.php');
	break;
	
	case "Newsletter":
		include('subjNewsletter.php');
	break;
	
	case "PowerchannelCatalog":
		include('subjPowerchannelCatalog.php');
	break;
	
	case "RFQ":
		include('subjRFQ.php');
	break;
	
	case "RMA":
		include('subjRMA.php');
	break;
	
	case "Sample":
		include('subjSample.php');
	break;
	
	case "Special":
		include('subjSpecial.php');
	break;
	
	case "TechnicalSupport":
		include('subjTechnicalSupport.php');
	break;
	
	default:
	
	break;
}
include('subjFeedback.php');
?>
</form>
