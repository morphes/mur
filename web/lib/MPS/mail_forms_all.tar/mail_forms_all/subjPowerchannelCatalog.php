<input type="hidden" name="subject" value="Powerchannel Catalog" />
<fieldset class="main">
	<legend>Request Literature</legend>
	<p>
	<label style="margin-top:20px;"><img src="/js/mps/putty2.jpg" alt="catalog" title="Request Literature"></label>
	<fieldset class="select_field">
		<legend>Product line(s) information</legend>
			<ul class="reqlit reqlit-title">
				<li></li>
				<li class="first">Product line(s)</li>
				<li class="box">Box</li>
				<li class="link">Download Link</li>
				<li>Quantity</li>
			</ul>
			<ul class="reqlit">
				<li><input type="checkbox" class="checkbox" name="NPI" value="YES"></li>
				<li class="first">New Product Catalog <img src="http://www.murata-ps.com/isroot/cd4power/SiteImages/new.gif" border="0" ALT=""></li>
				<li class="box">25/box</li>
				<li class="link"><a href="http://www.murata-ps.com/datasheet/?http://www.murata-ps.com/data/catalog_npi.pdf" class="blue">Download PDF</a></li>
				<li><input name="npi_quantity" type="text" size="3" maxlength="3"></li>
			</ul>
			<ul class="reqlit">
				<li><input type="checkbox" class="checkbox" name="DCDC" value="YES"></li>
				<li class="first"> DC/DC Converter Data Book</li>
				<li class="box">50/box</li>
				<li class="link"><a href="http://www.murata-ps.com/datasheet/?http://www.murata-ps.com/data/power/cd-dcdc_pdb1.pdf" class="blue">Download PDF</a></li>
				<li><input name="dcdc_quantity" type="text" size="3" maxlength="3"></li>
			</ul>
			<ul class="reqlit">
				<li><input type="checkbox" class="checkbox" name="ACDC" value="YES"></li>
				<li class="first">AC/DC Power Supplies <img src="http://www.murata-ps.com/isroot/cd4power/SiteImages/new.gif" border="0" alt="" /></li>
				<li class="box">25/box</li>
				<li class="link"><a href="http://www.murata-ps.com/datasheet/?http://www.murata-ps.com/data/acdcsupplies/psu_pdb1.pdf" class="blue">Download PDF</a></li>
				<li><input name="acdc_quantity" type="text" size="3" maxlength="3"></li>
			</ul>
			<ul class="reqlit">
				<li><input type="checkbox" class="checkbox" name="DPM" value="YES"></li>
				<li class="first">Digital Panel Meters <img src="http://www.murata-ps.com/isroot/cd4power/SiteImages/new.gif" border="0" alt=""></li>
				<li class="box">25/box</li>
				<li class="link"><a href="http://www.murata-ps.com/datasheet/?http://www.murata-ps.com/data/meters/dpm_pdb1.pdf" class="blue">Download PDF</a></li>
				<li><input name="dms_quantity" type="text" size="3" maxlength="3"></li>
			</ul>
			<ul class="reqlit">
				<li><input type="checkbox" class="checkbox" name="ADS" value="YES"></li>
				<li class="first">Data Acquisition Components</li>
				<li class="box">25/box</li>
				<li class="link"><a href="http://www.murata-ps.com/datasheet/?http://www.murata-ps.com/data/ads/cd-dac_pdb1.pdf" class="blue">Download PDF</a></li>
				<li><input name="ads_quantity" type="text" size="3" maxlength="3"></li>
			</ul>
			<ul class="reqlit">
				<li><input type="checkbox" class="checkbox" name="MAG" value="YES"></li>
				<li class="first">Magnetics</li>
				<li class="box">25/box</li>
				<li class="link"><a href="http://www.murata-ps.com/datasheet/?http://www.murata-ps.com/data/magnetics/c&d_mag_pdb1.pdf" class="blue">Download PDF</a></li>
				<li><input name="mag_quantity" type="text" size="3" maxlength="3"></li>
			</ul>
	</fieldset>
	</p>
</fieldset>