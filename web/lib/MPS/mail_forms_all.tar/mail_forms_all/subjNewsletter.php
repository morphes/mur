<input type="hidden" name="subject" value="eNewsletter" />
<fieldset class="main">
	<legend>Receive e-Specifier Newsletter</legend>
	<p>
	<!--<label style="margin-top:20px;">My Passive Component<br />Interests Are:<br /><img src="/js/mps/putty6.jpg" alt="Newsletter" title="e-Specifier Newsletter"></label>-->
	<fieldset class="select_field_checkbox_newsletter_col1">
		<!--<legend>Passive Component</legend>-->
		<legend><img src="/js/mps/logo_150_m.gif" alt="Newsletter" title="e-Specifier Newsletter"></legend>
			<h3>Passive Component</h3>
			<input type="checkbox" class="checkbox" name="MCCAPACITORS" value="YES">
			Multilayer Ceramic Capacitors<br />
			<input type="checkbox" class="checkbox" name="PCAPACITORS" value="YES">
			Polymer Capacitors<br />
			<input type="checkbox" class="checkbox" name="CIEF" value="YES">
			Chip Inductors and EMI Filters<br />
			<input type="checkbox" class="checkbox" name="ESD" value="YES">
			ESD Devices<br />
			<input type="checkbox" class="checkbox" name="WIRELESS" value="YES">
			Wireless  Module Solutions<br />
			<input type="checkbox" class="checkbox" name="SOUND" value="YES">
			Sound Components<br />
			<input type="checkbox" class="checkbox" name="TIMING" value="YES">
			Products for Timing Applications<br />
			<input type="checkbox" class="checkbox" name="CTPP" value="YES">
			Circuit and Thermal Protection Products<br />
			<input type="checkbox" class="checkbox" name="SENSORS" value="YES">
			Sensors<br />
			<input type="checkbox" class="checkbox" name="RF" value="YES">
			RF & Microwave Components, Sub-Modules<br />
			<input type="checkbox" class="checkbox" name="CERAMIC" value="YES">
			Ceramic Applied Products<br />
			<input type="checkbox" class="checkbox" name="HFCCONNECTORS" value="YES">
			High Frequency Coaxial Connectors<br />
			<input type="checkbox" class="checkbox" name="RFID" value="YES">
			RFID Solutions
	</fieldset>
	<!--<label style="margin-top:20px;">My Power Product<br />Interests Are:<br /><img src="/js/mps/putty7.jpg" alt="Newsletter" title="e-Specifier Newsletter"></label>-->
	<fieldset class="select_field_checkbox_newsletter_col2">
		<!--<legend>Power Product</legend>-->
		<legend><img src="/js/mps/logo_150_mps.gif" alt="Newsletter" title="e-Specifier Newsletter"></legend>
			<h3>Power Product</h3>
			<input type="checkbox" class="checkbox" name="DCDC" value="YES">
			DC/DC Converters<br />
			<input type="checkbox" class="checkbox" name="ACDC" value="YES">
			AC/DC Converters<br />
			<input type="checkbox" class="checkbox" name="DPM" value="YES">
			Digital Panel Meters and Instruments<br />
			<input type="checkbox" class="checkbox" name="MAG" value="YES">
			Magnetics<br />
			<input type="checkbox" class="checkbox" name="ADS" value="YES">
			Data Acquisition<br /><br />
			<input type="checkbox" class="checkbox" name="TP" value="YES">
			Technical Papers <span style="color:green">(new)</span><br />
			<input type="checkbox" class="checkbox" name="EOLV" value="YES">
			End-Of-Life Notices <span style="color:green">(new)</span>
	</fieldset>
	</p>
</fieldset>