<input type="hidden" name="subject" value="Catalog" />
<fieldset class="main">
	<legend>Request Literature</legend>
	<p>
		<label style="margin-top:20px;"><img src="/js/mps/putty2.jpg" alt="catalog" title="Request Literature"></label>
		<fieldset class="select_field">
		<legend>Information</legend>
			<ul class="reqlit reqlit-title">
				<li class=""></li>
				<li class="first-big">Product line(s)</li>
				<li class="link">Download Link</li>
			</ul>
			<ul class="reqlit">
				<li><input type="checkbox" class="checkbox" name="NPI" value="YES"></li>
				<li class="first-big">New Product Catalog <img src="http://www.murata-ps.com/isroot/cd4power/SiteImages/new.gif" border="0" ALT=""></li>
				<li class="link"><a href="http://www.murata-ps.com/datasheet/?http://www.murata-ps.com/data/catalog_npi.pdf" class="blue">Download PDF</a></li>
			</ul>
			<ul class="reqlit">
				<li><input type="checkbox" class="checkbox" name="DCDC" value="YES"></li>
				<li class="first-big"> DC/DC Converter Data Book</li>
				<li class="link"><a href="http://www.murata-ps.com/datasheet/?http://www.murata-ps.com/data/power/cd-dcdc_pdb1.pdf" class="blue">Download PDF</a></li>
			</ul>
			<ul class="reqlit">
				<li><input type="checkbox" class="checkbox" name="ACDC" value="YES"></li>
				<li class="first-big">AC/DC Converters Data Book <img src="http://www.murata-ps.com/isroot/cd4power/SiteImages/new.gif" border="0" alt="" /></li>
				<li class="link"><a href="http://www.murata-ps.com/datasheet/?http://www.murata-ps.com/data/acdcsupplies/psu_pdb1.pdf" class="blue">Download PDF</a></li>
			</ul>
			<ul class="reqlit">
				<li><input type="checkbox" class="checkbox" name="DPM" value="YES"></li>
				<li class="first-big">Digital Panel Meters Data Book <img src="http://www.murata-ps.com/isroot/cd4power/SiteImages/new.gif" border="0" alt=""></li>
				<li class="link"><a href="http://www.murata-ps.com/datasheet/?http://www.murata-ps.com/data/meters/dpm_pdb1.pdf" class="blue">Download PDF</a></li>
			</ul>
			<ul class="reqlit">
				<li><input type="checkbox" class="checkbox" name="ADS" value="YES"></li>
				<li class="first-big">Data Acquisition Components  Data Book</li>
				<li class="link"><a href="http://www.murata-ps.com/datasheet/?http://www.murata-ps.com/data/ads/cd-dac_pdb1.pdf" class="blue">Download PDF</a></li>
			</ul>
			<ul class="reqlit">
				<li><input type="checkbox" class="checkbox" name="MAG" value="YES"></li>
				<li class="first-big">Magnetics Selection Guide</li>
				<li class="link"><a href="http://www.murata-ps.com/datasheet/?http://www.murata-ps.com/data/magnetics/c&d_mag_pdb1.pdf" class="blue">Download PDF</a></li>
			</ul>
			<ul class="reqlit">
				<li><input type="checkbox" class="checkbox" name="MAGDB" value="YES" readonly="true"></li>
				<li class="first-big">Magnetics Data Book <span style="color:#FF0000">(download only)</span></li>
				<li class="link"><a href="http://www.murata-ps.com/datasheet/?http://www.murata-ps.com/data/magnetics/magnetics_mini_catalog.pdf" class="blue">Download PDF</a></li>
			</ul>
	</fieldset>
		</p>
</fieldset>
